# EDA-on-popular-OTT-platforms

As far as the current pandemic situation is concerned, OTT platforms act as one of the most entertaining factors and a significant stress reliever for people around the globe.

This project aims to explore all the movies in popular OTT platforms, inorder to gain interesting insights. This is carried out with the aid of a Kaggle dataset, collected from Netflix,PrimeVideo,Hulu and Disney+ API.


